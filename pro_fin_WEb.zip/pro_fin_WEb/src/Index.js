const express = require('express');
const morgan = require('morgan');
const path = require('path');
const exphbs = require('express-handlebars');
const session = require('express-session');
const validator = require('express-validator');
const passport = require('passport');
const flash = require('connect-flash');
const MySQLStore = require('express-mysql-session')(session);
const bodyParser = require('body-parser');

const { database } = require('./keys');

// Incializacion 
const app = express();

// configuraciones 
app.set('port', process.env.PORT || 4000);

// levantar el servidor 
app.listen(app.get('port'), () => {
    console.log('Server is in port', app.get('port'));
  });
  